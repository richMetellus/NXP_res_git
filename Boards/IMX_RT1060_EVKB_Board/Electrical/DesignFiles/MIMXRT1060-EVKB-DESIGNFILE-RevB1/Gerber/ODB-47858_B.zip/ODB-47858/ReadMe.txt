README for GRB-47858_B.zip

Company Part Number: 170-47858 REV B

Date: Mon, 22 Mar 2021 01:42:55 GMT

NXP Semiconductors
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : Xiaowei Xu
Work Phone          : 86-21-28930001
Email               : xiaowei.xu@nxp.com

CAD Manager
===========
Company Contact     : Daniel Kruczek
Work Phone          : 512-895-6081
Email               : daniel.kruczek@nxp.com

Manufacturing Program Manager
=============================
Company Contact     : Bobby Zhao
Work Phone          : 021-28937271
Email               : bobby.zhao@nxp.com

Product Engineer
================
Company Contact     : Dafne Arias
Work Phone          : ---
Email               : dafne.arias@nxp.com

Design for Manufacturing Engineer
=================================
Company Contact     : Rosalia Gonzalez
Work Phone          : +52(33) 3283-2100 x2267
Email               : HardwareSolutionsCoE-PCB@NXP1.onmicrosoft.com
